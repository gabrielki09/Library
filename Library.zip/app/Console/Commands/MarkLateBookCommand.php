<?php

namespace App\Console\Commands;

use Illuminate\Console\Attributes\Description;
use Illuminate\Console\Attributes\Signature;
use Illuminate\Console\Command;
use App\Book\BookLoansStatus;
use Illuminate\Support\Facades\DB;

#[Signature('app:mark-late-book-command')]
#[Description('Command description')]
class MarkLateBookCommand extends Command
{
    protected $signature = 'book-loans:mark-late';

    protected $description = 'Marca empréstimos como vencidos se a data de vencimento for inferior ao dia atual.';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $update = DB::connection('postgres')->table('book_loans')
        ->where('due_date', '<', now()->toDateString())
        ->whereNotIn('status', [
            'returned',
            'late',
            'canceled',
        ])
        ->update([
            'status' => BookLoansStatus::LATE->value,
            'updated_at' => now()
        ]);

        $this->info("Empréstimos marcados como atrasados: {$update}");

        return self::SUCCESS;
    }
}
